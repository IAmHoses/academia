package exceptions;

public class CommandLineArgumentException extends Exception {
	public CommandLineArgumentException(String message) {
		super (message);
	}
}
