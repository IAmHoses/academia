package exceptions;

public class IndexConfigException extends Exception {
	public IndexConfigException(String message) {
		super (message);
	}
}
