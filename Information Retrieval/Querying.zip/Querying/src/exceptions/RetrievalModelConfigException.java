package exceptions;

public class RetrievalModelConfigException extends Exception {
	public RetrievalModelConfigException(String message) {
		super (message);
	}
}
