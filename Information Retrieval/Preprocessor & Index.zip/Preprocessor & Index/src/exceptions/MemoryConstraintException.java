package exceptions;

public class MemoryConstraintException extends Exception {
	public MemoryConstraintException(String message) {
		super(message);
	}
}
