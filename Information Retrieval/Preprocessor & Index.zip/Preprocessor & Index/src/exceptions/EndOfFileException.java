package exceptions;

public class EndOfFileException extends Exception {
	public EndOfFileException(String message) {
		super(message);
	}
}
