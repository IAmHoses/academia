
//
// CS354: Shell project
//
// Template file. 
// You will need to add more code here to execute the command table
////
// NOTE: You are responsible for fixing any bugs this
// code may have.

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <signal.h>

//  for c system calls, specifically open()
#include <fcntl.h>

/* Not technically required, but needed on some UNIX distributions */
#include <sys/types.h>
#include <sys/stat.h>

#include "command.h"

SimpleCommand::SimpleCommand()
{
	// Creat available space for 5 arguments
	_numberOfAvailableArguments = 5;
	_numberOfArguments = 0;
	_arguments = (char **) malloc( _numberOfAvailableArguments * sizeof( char * ) );
}

void
SimpleCommand::insertArgument( char * argument )
{
	if ( _numberOfAvailableArguments == _numberOfArguments  + 1 ) {
		// Double the available space
		_numberOfAvailableArguments *= 2;
		_arguments = (char **) realloc( _arguments,
				  _numberOfAvailableArguments * sizeof( char * ) );
	}
	
	_arguments[ _numberOfArguments ] = argument;

	// Add NULL argument at the end
	_arguments[ _numberOfArguments + 1] = NULL;
	
	_numberOfArguments++;
}

Command::Command()
{
	// Create available space for one simple command
	_numberOfAvailableSimpleCommands = 1;
	_simpleCommands = (SimpleCommand **)
		malloc( _numberOfSimpleCommands * sizeof( SimpleCommand * ) );

	_numberOfSimpleCommands = 0;
	_outFile = 0;
	_inputFile = 0;
	_errFile = 0;
	_background = 0;
}

void
Command::insertSimpleCommand( SimpleCommand * simpleCommand )
{
	if ( _numberOfAvailableSimpleCommands == _numberOfSimpleCommands ) {
		_numberOfAvailableSimpleCommands *= 2;
		_simpleCommands = (SimpleCommand **) realloc( _simpleCommands,
			 _numberOfAvailableSimpleCommands * sizeof( SimpleCommand * ) );
	}
	
	_simpleCommands[ _numberOfSimpleCommands ] = simpleCommand;
	_numberOfSimpleCommands++;
}

void
Command:: clear()
{
	for ( int i = 0; i < _numberOfSimpleCommands; i++ ) {
		for ( int j = 0; j < _simpleCommands[ i ]->_numberOfArguments; j ++ ) {
			free ( _simpleCommands[ i ]->_arguments[ j ] );
		}
		
		free ( _simpleCommands[ i ]->_arguments );
		free ( _simpleCommands[ i ] );
	}

	if ( _outFile ) {
		free( _outFile );
	}

	if ( _inputFile ) {
		free( _inputFile );
	}

	if ( _errFile ) {
		free( _errFile );
	}

	_numberOfSimpleCommands = 0;
	_outFile = 0;
	_inputFile = 0;
	_errFile = 0;
	_background = 0;
}

void
Command::print()
{
	printf("\n\n");
	printf("              COMMAND TABLE                \n");
	printf("\n");
	printf("  #   Simple Commands\n");
	printf("  --- ----------------------------------------------------------\n");
	
	for ( int i = 0; i < _numberOfSimpleCommands; i++ ) {
		printf("  %-3d ", i );
		for ( int j = 0; j < _simpleCommands[i]->_numberOfArguments; j++ ) {
			printf("\"%s\" \t", _simpleCommands[i]->_arguments[ j ] );
		}
	}

	printf( "\n\n" );
	printf( "  Output       Input        Error        Background\n" );
	printf( "  ------------ ------------ ------------ ------------\n" );
	printf( "  %-12s %-12s %-12s %-12s\n", _outFile?_outFile:"default",
		_inputFile?_inputFile:"default", _errFile?_errFile:"default",
		_background?"YES":"NO");
	printf( "\n\n" );
	
}

void
Command::execute()
{
	// Don't do anything if there are no simple commands
	if ( _numberOfSimpleCommands == 0 ) {
		prompt();
		return;
	}

	// Print contents of Command data structure
	print();

	// Add execution here
	// For every simple command fork a new process
	// Setup i/o redirection
	// and call exec
    
    int pid = -1;   // initialize to error return value just in case!
    
    // Save default input, output, and error because we will
    // change them during redirection and we will need to restore them
    // at the end.
    
    int defaultin = dup( 0 );
    int defaultout = dup( 1 );
    int defaulterr = dup( 2 );
//    printf("defaultin file descriptor: %d\n", defaultin);
//    printf("defaultout file descriptor: %d\n", defaultout);
//    printf("defaulterr file descriptor: %d\n", defaulterr);
    
    // Initialize file redirection descriptors so they'll be used later!
    int inputFileDescriptor = -1;
    int outputFileDescriptor = -1;
    int errorFileDescriptor = -1;
    
    for ( int i = 0; i < _numberOfSimpleCommands; i++ ) {

        // set up file redirection before creating new process
        if (_inputFile == NULL && _outFile == NULL && _errFile == NULL) {
            printf("Default output, input, and error being used for current simple command\n");
            dup2(defaultin, 0);
            dup2(defaultin, 1);
            dup2(defaultin, 2);
        }
        
        if (_inputFile != NULL) {
            printf("Specified output file: %s\n", _outFile);
        }
        
        if (_outFile != NULL) {
            printf("Specified output file: %s\n", _outFile);
            printf("File output redirection operator: %s\n", _outputRedirectionOperator);
            
            if (_outputRedirectionOperator == ">") {
                // Redirect output to specified file
                outputFileDescriptor = open(_outFile, O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
                dup2(outputFileDescriptor, 1);
                
                // close deprecated file descriptor
                close(defaultout);
            }
        }
        
        if (_errFile != NULL) {
            printf("Specified output file: %s\n", _outFile);
        }
        
        // create new process for current simple command
        pid = fork();
        printf("pid returned from fork: %d\n", pid);
        
        if ( pid == -1 ) {
            // fork error
            perror( strcat(_simpleCommands[i]->_arguments[0], ": fork\n"));
            exit( 2 );
        }
        
        if (pid == 0) {
            // in Child
            
            // close file descriptors that are not needed
//            close(fdpipe[0]);
//            close(fdpipe[1]);
//            close( defaultin );
//            close( defaultout );
//            close( defaulterr );
            
            if (inputFileDescriptor != -1) {
                close( defaultin );
            }
            if (outputFileDescriptor != -1) {
                close( defaultout );
            }
            if (errorFileDescriptor != -1) {
                close( defaulterr );
            }
            
            execvp(_simpleCommands[i]->_arguments[0], _simpleCommands[i]->_arguments);
            
            // exec() is not suppose to return, something went wrong
            perror( strcat("command: exec ", _simpleCommands[i]->_arguments[0]));
            exit( 2 );
        }
    }

	// Clear to prepare for next command
	clear();
    
    // Restore default input, output, and error
    dup2( defaultin, 0 );
    dup2( defaultout, 1 );
    dup2( defaulterr, 2 );
    
    // Close file descriptors that are not needed
//    close(fdpipe[0]);
//    close(fdpipe[1]);
//    close( defaultin );
//    close( defaultout );
//    close( defaulterr );
    
    if (inputFileDescriptor != -1) {
        close( defaultin );
    }
    if (outputFileDescriptor != -1) {
        close( defaultout );
    }
    if (errorFileDescriptor != -1) {
        close( defaulterr );
    }
    
    // Wait for last process in the pipe line
    
    if (pid > 0 && _background == 0) {
        // in Parent AND no background flag
        
        printf("Attempting waitpid for pid %d...\n", pid);
        waitpid(pid, 0, 0);
        printf("Waitpid successful!\n");
    }
	
	// Print new prompt
	prompt();
}

// Shell implementation

void
Command::prompt()
{
	printf("myshell>");
	fflush(stdout);
}

Command Command::_currentCommand;
SimpleCommand * Command::_currentSimpleCommand;

int yyparse(void);

main()
{
	Command::_currentCommand.prompt();
	yyparse();
}

