package scheduling;

public class SchedulingAlgorithmArgumentException extends Exception {
	public SchedulingAlgorithmArgumentException (String message) {
		super(message);
	}
}
