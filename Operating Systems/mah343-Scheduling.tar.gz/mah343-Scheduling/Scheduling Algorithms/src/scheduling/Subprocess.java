package scheduling;

public class Subprocess {
	private String type;
	private Integer time;
	
	public Subprocess (String type, Integer time) {
		this.type = type;
		this.time = time;
	}
	
	public String getType () {
		return type;
	}
	
	public Integer getTime () {
		return time;
	}
	
	public void subtractTime (Integer difference) {
		time -= difference;
	}
}
